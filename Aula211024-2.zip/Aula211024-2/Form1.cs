﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula211024
{
    public partial class Form1 : Form
    {
        string nome;
        string sobrenome;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BackColor = button1.BackColor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BackColor = button2.BackColor;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.BackColor = button3.BackColor;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

            if(txbNome.Text == "" || txbSobrenome.Text == "")
            {
                MessageBox.Show("Um dos campos está vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string nome_completo;
                nome_completo = txbNome.Text + " " + txbSobrenome.Text;
                txbResultado.Text = nome_completo;

                comboBox1.Items.Add(nome_completo);
                txbNome.Clear();
                txbSobrenome.Clear();

            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selecionado;
            selecionado = comboBox1.SelectedItem.ToString();
            lblResultado.Text = selecionado;
        }
    }
}

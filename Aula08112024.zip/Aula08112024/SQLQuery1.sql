﻿CREATE TABLE [dbo].[TipoTelefone]
(
	[IdTipo] INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
	[Nome] NVARCHAR(MAX)
);


INSERT INTO TipoTelefone(Nome) VALUES('Celular');


SELECT * FROM TipoTelefone
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal class Time
    {
        public List<Jogador> jogadores { get; private set; }

        public Tecnico tec { get; private set; }

        public Time(Tecnico tec)
        {
            this.jogadores = new List<Jogador>();
            this.tec = tec;
        }

        public void AdicionarJogador(string nome, string cpf)
        {
            jogadores.Add(new Jogador(nome, cpf));
        }

    }
}

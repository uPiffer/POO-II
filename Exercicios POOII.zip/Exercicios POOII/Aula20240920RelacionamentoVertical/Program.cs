﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240920RelacionamentoVertical
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Derivada d1 = new Derivada(3,4);
            Derivada d2 = new Derivada(1, 2);
            Derivada d3 = new Derivada(5, 6);

            Base b1 = new Base(7,8);
            Base b2 = new Base(4, 1);

            List<Derivada> l1 = new List<Derivada>();
            l1.Add(d1);
            // l1.Add(b1);

            List<Base> l2 = new List<Base>();
            l2.Add(b1);
            l2.Add(b2);
            l2.Add(d3);
            l2.Add(d2);
            l2.Add(d1);

            foreach (Base l in l2) {
                l.Metodo3();
            }

        }
    }
}

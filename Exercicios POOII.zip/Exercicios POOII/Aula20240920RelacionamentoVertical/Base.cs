﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240920RelacionamentoVertical
{
    public class Base
    {
        private int atributo1 { get; set; }
        public int atributo2 { get; set; }

        public Base(int atributo1, int atributo2)
        {
            Console.WriteLine("Criação da BASE.");
            this.atributo1 = atributo1;
            this.atributo2 = atributo2;
        }

        public void Metodo1() {
            Console.WriteLine("Executando método 1");
        }

        private void Metodo2()
        {
            Console.WriteLine("Executando método 2");
        }

        public virtual void Metodo3()
        {
            Console.WriteLine("Executando método 3");
        }

        public  void Metodo3(int x)
        {
            Console.WriteLine("Executando método 3 com adicional de "+x.ToString());
        }
    }
}

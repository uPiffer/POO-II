﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240823
{
    internal class ListaTelefonica
    {
        public string proprietario { get; set; }
        private List<Contato> contatos;

        public ListaTelefonica(string proprietario)
        {
            this.proprietario = proprietario;
            contatos = new List<Contato>();
        }

        public void adicionar(string nome, string telefone, string tipo) {
            Contato auxiliar = new Contato(nome, telefone, tipo);
            contatos.Add(auxiliar);

            //contatos.Add(new Contato(nome, telefone, tipo));
        }

        public void imprimir() {
            Console.WriteLine("a:");
            foreach (Contato c in contatos)
            {
                Console.WriteLine("Contato:"+c.nome+" / "+c.numero+" / "+c.tipo);
            }
        }

        public void remover(string n)
        {
            foreach (Contato c in contatos)
            {
                if (c.nome == n)
                {
                    contatos.Remove(c);
                }
            }
        }


    }
}

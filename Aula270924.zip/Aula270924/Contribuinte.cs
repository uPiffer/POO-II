﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula270924
{
    public abstract class Contribuinte
    {
        protected string nome;
        protected double rendaBruta;

        public Contribuinte(string nome, double rendaBruta)
        {
            this.nome = nome;
            this.rendaBruta = rendaBruta;
        }

        public abstract double CalcularImposto();
    }
}

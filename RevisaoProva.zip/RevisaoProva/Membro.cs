﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal abstract class Membro
    {
        public string nome { get; set; }
        public string CPF { get; set; }

        protected Membro(string nome, string cPF)
        {
            this.nome = nome;
            CPF = cPF;
        }

        public bool ValidarCPF(string CPF)
        {
            return CPF.Length == 11;
        }

        public abstract void Jogar();


    }
}

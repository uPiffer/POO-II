﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula251024
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cbxTipo.Items.Add("Celular");
            cbxTipo.Items.Add("Whatsapp");
            cbxTipo.Items.Add("Fixo");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                btnAdd.Enabled = true;
            }
            else
            {
                btnAdd.Enabled=false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string contato;
            if (txbNome.Text == "" || txbTelefone.Text == "" || cbxTipo.SelectedIndex == -1)
            {
                MessageBox.Show("Um dos campos está vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                List<string> contatos = new List<string>();
                contatos.Add(txbNome.Text + " " + txbTelefone.Text + " " + cbxTipo.Text.ToString());
                listBox1.Items.Add(contatos);
            }


            

        }
    }
}

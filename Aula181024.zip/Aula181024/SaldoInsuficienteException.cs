﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula181024
{
    internal class SaldoInsuficienteException : Exception
    {
        public int numeroConta { get; set; }

        public SaldoInsuficienteException(int numeroConta, string message):base(message)
        {
            this.numeroConta = numeroConta;
        }
    }
}

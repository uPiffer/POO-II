﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula20241104_AgendaTelefonicaV3
{
    public partial class Form1 : Form
    {
        public List<Contato> listaContatos;
        public List<String> listaTipos;

        public Form1()
        {
            InitializeComponent();
            
            listaContatos = new List<Contato>();
            listaTipos = new List<String>();
            listaTipos.AddRange(new string[] { "", "Celular","Whatsapp", "Residencial"});
            
        }

        private void cbxAceito_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            Form3 telaAdicionar = new Form3(this);
            telaAdicionar.ShowDialog();

        }

        public void AtualizaGrid() {
            dgvContatos.DataSource = null;
            dgvContatos.DataSource = listaContatos;

            dgvContatos.Columns["nome"].HeaderText = "Nome";
            dgvContatos.Columns["telefone"].HeaderText = "Telefone";
            dgvContatos.Columns["idTipo"].HeaderText = "Tipo Telefone";
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if(dgvContatos.SelectedRows.Count > 0)
            {
                int index = dgvContatos.SelectedRows[0].Index;
                if (index >= 0 && index < listaContatos.Count)
                {
                    listaContatos.RemoveAt(index);
                    AtualizaGrid();

                }
            }
            else
            {
                MessageBox.Show("Selecione uma linha inteira");
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (dgvContatos.CurrentCell != null)
            {
                int index =dgvContatos.CurrentCell.RowIndex;
                if (index >= 0 && index < listaContatos.Count)
                {
                    Contato contatoSelecionado = listaContatos[index];
                    contatoSelecionado.nome = dgvContatos.Rows[index].Cells["nome"].Value?.ToString();
                    contatoSelecionado.telefone = dgvContatos.Rows[index].Cells["telefone"].Value?.ToString();
                    contatoSelecionado.idTipo = Convert.ToInt32(dgvContatos.Rows[index].Cells["idTipo"].Value?.ToString());

                    AtualizaGrid();
                }
            }
            else
            {
                MessageBox.Show("Selecione uma célula");

            }
        }
    }
}

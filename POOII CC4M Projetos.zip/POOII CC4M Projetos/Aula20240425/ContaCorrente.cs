﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240425
{
    internal class ContaCorrente
    {
        public int agencia;
        public int numero;
        public double saldo;

        public ContaCorrente(int agencia, int numero, double saldo)
        {
            this.agencia = agencia;
            this.numero = numero;
            this.saldo = saldo;
        }

        public void Sacar(double valor) {
            if (saldo < valor)
            {
                Console.WriteLine("Impossivel.");
                throw new SaldoInsuficienteException(numero, "Sem saldo.");
            }
            else
            {
                //int a=0, b=3;
                //int x = b / a;
                saldo -= valor;
            }
        }
    }
}

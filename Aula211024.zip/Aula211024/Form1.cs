﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula211024
{
    public partial class Form1 : Form
    {
        string nome;
        string sobrenome;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BackColor = button1.BackColor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BackColor = button2.BackColor;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.BackColor = button3.BackColor;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            /*
             FAZENDO UTILIZANDO VARIAVEIS NOME E SOBRENOME PARA SALVAR O NOME
            
            nome = txbNome.Text;
            sobrenome = txbSobrenome.Text;

            txbResultado.Text = nome + " " + sobrenome;
            */

            txbResultado.Text = txbNome.Text + " " + txbSobrenome.Text; // FAZENDO DIRETO
            txbResultado.Enabled = true; //ATIVANDO PARA APARECER O TEXTBOX (ELE TBM VAI ESTAR APENAS COMO READONLY)
            comboBox1.Items.Add(txbResultado.Text);
            lblResultado.Text = comboBox1.SelectedText; //TERMINAR
        }
    }
}

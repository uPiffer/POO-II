﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Tecnico t = new Tecnico("Gabriel", "12345678900");

            Time time = new Time(t);

            time.AdicionarJogador("Joao", "11122233300");
            time.AdicionarJogador("Eduardo", "99988877700");
            time.AdicionarJogador("Guilherme", "55544433300");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240902Bidirecional
{
    internal class Professor
    {
        public string nome { get; set; }
        public string cpf { get; set; }
        public List<Disciplina> dis { get; set; }

        public Professor(string nome, string cpf)
        {
            this.nome = nome;
            this.cpf = cpf;
            dis = new List<Disciplina>();
        }

        public void addDisciplina(Disciplina d) { 
            dis.Add(d);
            d.addProfessor(this);
        }
    }
}

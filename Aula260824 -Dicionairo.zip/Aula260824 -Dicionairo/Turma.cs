﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240826_Dicionairo
{
    internal class Turma
    {
        public string nome { get; set; }
        public int ano { get; set; }
        private Dictionary<string, Aluno> alunos;

        public Turma(string nome, int ano)
        {
            this.nome = nome;
            this.ano = ano;
            alunos = new Dictionary<string, Aluno>();
        }

        public void imprimirAlunos() {
            Console.WriteLine($"Turma: {nome} - Ano: {ano}");
            foreach(string matricula in alunos.Keys)
            {
                Console.WriteLine($"Aluno: {alunos[matricula].nome}" +
                    $"Matricula: {matricula}");
            }
        }

        public void removerAluno(string matricula) {
            if (!alunos.ContainsKey(matricula))
            {
                Console.WriteLine("ERRO");
            }
            else
            {
                alunos.Remove(matricula);
                Console.WriteLine("Removido com sucesso");
            }
        }

        public void adicionarAluno(Aluno aluno) {
            if (alunos.ContainsKey(aluno.matricula))
            {
                Console.WriteLine("ERRO");
            }
            else
            {
                alunos.Add(aluno.matricula, aluno);
            }
            
        }

        public void quantidadeAlunos() { 
            Console.WriteLine("Quantidade: " + alunos.Count);
         }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240826_Dicionairo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aluno a1 = new Aluno("Gabriel", "1234567890");
            Aluno a2 = new Aluno("Calango", "0987654321");
            Aluno a3 = new Aluno("Guerald", "12312312312");

            Turma t1 = new Turma("CC/EO", 2024);
            t1.adicionarAluno(a1);
            t1.adicionarAluno(a2);
            t1.adicionarAluno(a3);

            t1.imprimirAlunos();
        }
    }
}

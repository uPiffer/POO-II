﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula18042024
{
    internal class Program
    {
        static void Main(string[] args)
        {

            try
            {
                int filhos = 0;
                bool vivo = true;
                double heranca = 190000.00, quantiaFilhos;

                if(!vivo)
                {
                    Console.WriteLine("Sem herança. O velho ainda está vivo.");
                }

            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("ERRO - VELHO NÃO POSSUI FILHOS");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Finalizando...");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula120824
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTime nascimento = new DateTime(2003,08,15); //Botando o nascimento dentro de uma variavel
            Aluno a = new Aluno("Gabriel", "12345678900", nascimento); //Instanciando a classe aluno
            Aluno b = new Aluno("Gabriel2", "00987654321", nascimento);

            Console.WriteLine(a.nome);
            Console.WriteLine(a.matricula);
            Console.WriteLine(a.dataNascimento);
            Console.WriteLine(a.getIdade());
            Console.WriteLine(b.nome);
            Console.WriteLine(b.matricula);
            Console.WriteLine(b.dataNascimento);
            Console.WriteLine(Aluno.ObterContador());
        }
    }
}

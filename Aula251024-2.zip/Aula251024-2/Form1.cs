﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Aula251024
{
    public partial class Form1 : Form
    {
        private List<Contato> contatos = new List<Contato>();
        public Form1()
        {
            InitializeComponent();
            cbxTipo.Items.Add("Celular");
            cbxTipo.Items.Add("Whatsapp");
            cbxTipo.Items.Add("Fixo");
            btnAdd.Enabled = false;

            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
        }
        public class Contato
        {
            public string Nome { get; set; }
            public string Telefone { get; set; }
            public string Tipo { get; set; }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = checkBox1.Checked; 
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txbNome.Text == "" || txbTelefone.Text == "" || cbxTipo.SelectedIndex == -1)
            {
                MessageBox.Show("Um dos campos está vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Contato novoContato = new Contato
            {
                Nome = txbNome.Text,
                Telefone = txbTelefone.Text,
                Tipo = cbxTipo.SelectedItem.ToString()
            };
            contatos.Add(novoContato);

            listBox1.Items.Add(novoContato.Nome);

            txbNome.Clear();
            txbTelefone.Clear();
            cbxTipo.SelectedIndex = -1;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index >= 0 && index < contatos.Count)
            {
                Contato contatoSelecionado = contatos[index];

                txbResultadoNome.Text = contatoSelecionado.Nome;
                txbResultadoTelefone.Text = contatoSelecionado.Telefone;
                txbResultadoTipo.Text = contatoSelecionado.Tipo;
            }
            else
            {

                txbResultadoNome.Clear();
                txbResultadoTelefone.Clear();
                txbResultadoTipo.Clear();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240826_Dicionairo
{
    internal class Professor
    {
        public string nome { get; set; }
        public string cpf { get; set; }
        public List<Disciplina> dis { get; set; }
        


        public Professor(string nome, string cpf)
        {
            this.nome = nome;
            this.cpf = cpf;
            dis = new List<Disciplina>();
        }
        public void adicionarDisciplina (Disciplina disciplina)
        {
            dis.Add(disciplina);
            disciplina.adicionarProfessor(this);
        }
    }
}

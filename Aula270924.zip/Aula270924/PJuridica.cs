﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula270924
{
    internal class PJuridica: Contribuinte
    {
        private string cnpj;
        public PJuridica(string cnpj, string nome, double rb) : base(nome, rb)
        {
            this.cnpj = cnpj;
        }

        public override double CalcularImposto()    
        {
            Console.WriteLine("Calculando imposto de Pessoa Juridica");

            return this.rendaBruta * 0.1;
        }

        public string Imprimir()
        {
            return $"\n Nome PJ: {this.nome}\n" +
                $"RendaBruta: {this.rendaBruta:F2}\n";
        }



    }
}

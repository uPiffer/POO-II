﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240417
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Banco banco = new Banco();
            banco.inserir("cp", new Conta("cp", "Cassio", 100););

            banco.listarTodos();
            

        }
    }
}

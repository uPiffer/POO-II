﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula181024
{
    internal class ContaCorrente
    {
        private int agencia;
        private int numero;
        private double saldo;

        public ContaCorrente(int agencia, int numero, double saldo)
        {
            this.agencia = agencia;
            this.numero = numero;
            this.saldo = saldo;
        }

        public void Sacar(double valor)
        {
            if(saldo < valor)
            {
                //Console.WriteLine("Valor insuficiente");
                throw new Exception("Valor insuficiente");
            }
            else
            {
                saldo -= valor;
                Console.WriteLine("Saque realizado");
            }
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula120824
{
    internal class Aluno
    {
        private static int quantidade_alunos;
        public string matricula { get; private set; } //Deixando somente a função de get
        public string nome { get; set; }
        public string cpf { get; set; }
        public DateTime criacao { get; private set; }
        public float nota1B {  get; set; }
        public float nota2B { get; set; }
        public float final {  get; private set; }
        public int periodo { get; private set; }
        public DateTime dataNascimento { get; private set; }

        public Aluno(string nome, string cpf, DateTime dataNascimento) // Construtor
        {
            quantidade_alunos++;
            this.matricula = GerarMatricula();
            this.nome = nome;
            this.cpf = cpf;
            this.criacao = DateTime.Now;
            this.nota1B = 0;
            this.nota2B = 0;
            this.final = 0;
            this.periodo = 1;
            this.dataNascimento = dataNascimento;
        }

        private string GerarMatricula()
        {
            int ano = DateTime.Now.Year;
            Random rand = new Random();
            int aleatorio = rand.Next(1000,9999);
            return $"{ano:D4}{aleatorio:D4}";
        }

        public static int ObterContador()
        {
            return quantidade_alunos;
        }

        public int getIdade()
        {
            int idade = 0;

            DateTime hoje = DateTime.Now;
            idade = hoje.Year - dataNascimento.Year;

            if(dataNascimento.Date > hoje.AddYears(-idade))
            {
                idade--;
            }

            return idade;
        }


    }
}

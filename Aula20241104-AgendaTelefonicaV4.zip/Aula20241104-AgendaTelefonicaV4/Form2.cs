﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula20241104_AgendaTelefonicaV3
{
    public partial class Form2 : Form
    {
        Form1 formAnterior;
        public Form2(Form1 formAnterior)
        {
            InitializeComponent();
            this.formAnterior = formAnterior;   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            formAnterior.
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240802___Exemplos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String x ;
            Console.WriteLine("Digite um numero: ");
            x = Console.ReadLine();
            Console.Write($"Olá {x}!\n");

            /*
             * 1- Pegar um numero, dizer se é par ou impar, 
             * e se é positivo ou negativo
             * 
             * 2- Dado um numero, verificar a quantidade de 
             * ocorrências de cada digito.
             * 
             * 3- Dado um numero entre 0 e 9, imprima DE FORMA BONITA a 
             * tabuada de multiplicação de 0 a 10.
            */
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula181024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ContaCorrente c1 = new ContaCorrente(12, 24, 1000);
            try
            {
                c1.Sacar(5000);
            }
            catch (SaldoInsuficienteException ex) 
            {
                Console.WriteLine(ex.Message + " SaldoInsuficienteException ");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + " Exception ");
            }
            finally
            {
                Console.WriteLine("Finalizado");
            }

        }
    }
}

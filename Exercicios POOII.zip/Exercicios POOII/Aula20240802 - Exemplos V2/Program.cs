﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240802___Exemplos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aluno a = new Aluno("João", "123.456.789-00");

            Console.WriteLine(a.nome);
            Console.WriteLine(a.matricula);


        }
    }
}

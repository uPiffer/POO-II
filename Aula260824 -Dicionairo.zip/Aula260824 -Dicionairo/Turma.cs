﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240826_Dicionairo
{
    internal class Turma
    {
        public string nome { get; set; }
        public int ano { get; set; }
        private Dictionary<string, Aluno> alunos;

        public Turma(string nome, int ano)
        {
            this.nome = nome;
            this.ano = ano;
            alunos = new Dictionary<string, Aluno>();
        }

        public void imprimirAlunos() { 
        
        }

        public void removerAluno(string matricula) { 
        
        }

        public void adicionarAluno(Aluno aluno) { 
        
        }

        public void quantidadeAlunos() { 
        
         }

    }
}
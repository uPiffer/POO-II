﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula230824
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*

            //Estudando Lista

            List<String> dias;
            dias = new List<String>(); //Instanciando a lista dias

            dias.Add("segunda");
            dias.Add("terça");
            dias.Add("quarta");
            dias.Add("quinta");
            dias.Add("sexta");
            dias.Add("sabado");
            dias.Add("domingo");


            foreach(String s in dias)
            {
                Console.WriteLine(s);
            }

            if (dias.Remove("terça"))
            {
                Console.WriteLine("Removido");
            }
            else
            {
                Console.WriteLine("Erro");
            }

            Console.WriteLine(dias.Count()); //Contador de itens na lista
            dias.Contains("xxx");

            */

            ListaTelefonica l = new ListaTelefonica("Gabriel");
            l.Inserir("João", "121232414", "Celular");
            l.Inserir("Caio", "122143324", "Whatsapp");
            l.Imprimir();











            
        }
    }
}

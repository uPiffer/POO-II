﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula20241104_AgendaTelefonicaV3
{
    public partial class Form3 : Form
    {
        Form1 telaPrincipal;
        public Form3(Form1 telaParametro)
        {
            InitializeComponent();
            btnAdicionar.Enabled = false;

            this.telaPrincipal = telaParametro;

            cbxTipo.DataSource = telaPrincipal.listaTipos;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (cbxAceito.Checked)
            {
                if (!string.IsNullOrEmpty(txbNome.Text) &&
                    !string.IsNullOrEmpty(txbTelefone.Text) &&
                    cbxTipo.SelectedIndex > 0)
                {
                    Contato temp = new Contato(txbNome.Text, txbTelefone.Text,
                        cbxTipo.SelectedIndex);
                    telaPrincipal.listaContatos.Add(temp);

                    txbNome.Clear();
                    txbTelefone.Clear();
                    cbxTipo.SelectedIndex = -1;
                    cbxAceito.Checked = false;

                    telaPrincipal.AtualizaGrid();

                    this.Close();
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos");
                }
            }
            else
            {
                MessageBox.Show("Aceite os termos.");
            }

        }

        private void cbxAceito_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxAceito.Checked)
            {
                btnAdicionar.Enabled = true;
            }
            else
            {
                btnAdicionar.Enabled = false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula270924
{
    internal class PFisica: Contribuinte, iPrint
    {
        private string cpf;

        public PFisica(string cpf, string nome, double rb): base(nome, rb)
        {
            this.cpf = cpf;
        }


        public override double CalcularImposto()
        {
            Console.WriteLine("Calculando imposto de Pessoa Fisica");

            double aliquota = 0;
            double parcelaDeduzir = 0;

            if(this.rendaBruta <= 1400)
            {
                aliquota = 0;
                parcelaDeduzir = 0;
            }else if(this.rendaBruta <= 2100)
            {
                aliquota = 0.1;
                parcelaDeduzir = 100;
            }else if(this.rendaBruta <= 2800)
            {
                aliquota = 0.15;
                parcelaDeduzir = 270;
            }else if(this.rendaBruta <= 3600)
            {
                aliquota = 0.25;
                parcelaDeduzir = 500;
            }
            else
            {
                aliquota = 0.3;
                parcelaDeduzir = 700;
            }


            return (this.rendaBruta * aliquota) - parcelaDeduzir;
        }

        public string Imprimir()
        {
            return $"\n Nome PF: {this.nome}\n" +
                $"RendaBruta: {this.rendaBruta:F2}\n";
        }
    }
}

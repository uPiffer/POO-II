﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Aula20240812
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nome = "Cassio";
            string cpf = "147852369-00";
            DateTime nascimento = new DateTime(1991, 02, 01);

            Aluno a = new Aluno(nome, cpf, nascimento);
           
            Console.WriteLine(Aluno.ObterContador());
            Console.WriteLine(Aluno.
        }
    }
}

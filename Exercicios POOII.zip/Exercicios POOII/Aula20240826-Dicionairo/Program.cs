﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240826_Dicionairo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aluno a1 = new Aluno("joao", "11111111111");
            Aluno a2 = new Aluno("Ana", "22222222222");
            Aluno a3 = new Aluno("enzo", "33333333333");

            Turma t1 = new Turma("EO4M","2024");

            t1.adicionarAlunos(a1);
            t1.adicionarAlunos(a2);
            t1.adicionarAlunos(a3);
            t1.imprimirAlunos();
        }
    }
}
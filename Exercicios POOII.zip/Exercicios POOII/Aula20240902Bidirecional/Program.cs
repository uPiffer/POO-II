﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240902Bidirecional
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Disciplina d1 = new Disciplina("POO1", 80);
            Disciplina d2 = new Disciplina("POO2", 80);
            Disciplina d3 = new Disciplina("Eng. Soft.", 80);
            Disciplina d4 = new Disciplina("ED1", 80);
            Disciplina d5 = new Disciplina("ED2", 80);

            Professor p1 = new Professor("Cassio", "111");
            Professor p2 = new Professor("Vinicius", "222");
            Professor p3 = new Professor("Saulo", "333");
            Professor p4 = new Professor("Brantes", "444");

            p1.addDisciplina(d2);
            p1.addDisciplina(d3);

            //d2.profs.Add(p1);
            //d3.profs.Add(p1);







        }
    }
}

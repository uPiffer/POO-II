﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula20241028_AgendaTelefonica
{
    public partial class Form1 : Form
    {
        private List<Contato> listaContatos;
        private List<String> listaTipos;
        public Form1()
        {
            InitializeComponent();
            btnAdicionar.Enabled = false;
            listaTipos = new List<string>();
            listaTipos.AddRange(new string[] { "", "Celular", "Whatsapp", "Residencial" });
            cbxTipo.DataSource = listaTipos;
            listaContatos = new List<Contato>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ckbAceite.Checked)
            {
                if (!string.IsNullOrEmpty(txbNome.Text) &&
                    !string.IsNullOrEmpty(txbTelefone.Text) &&
                    cbxTipo.SelectedIndex > 0)
                {

                    Contato temp = new Contato(txbNome.Text,
                        txbTelefone.Text, cbxTipo.SelectedIndex);

                    listaContatos.Add(temp);

                    txbNome.Clear();
                    txbTelefone.Clear();
                    cbxTipo.SelectedIndex = -1;

                    lstContatos.DataSource = null;
                    lstContatos.DataSource = listaContatos;

                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = listaContatos;
                    dataGridView1.Refresh();

                    txbSelecaoNome.Clear();
                    txbSelecaoTelefone.Clear();
                    //txbSelecaoTipo.Clear();
                }
                else {
                    MessageBox.Show("Preencha os campos.");
                }
            }
            else {
                MessageBox.Show("Aceite os termos.");
            }
        }

        private void ckbAceite_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbAceite.Checked)
            {
                btnAdicionar.Enabled = true;
            }
            else {
                btnAdicionar.Enabled = false;
            }
        }

        private void lstContatos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstContatos.SelectedItem is Contato contatoSelecionado) {

                txbSelecaoNome.Clear();
                txbSelecaoTelefone.Clear();
                cbxSelecaoTipo.SelectedIndex = -1;

                txbSelecaoNome.Text = contatoSelecionado.nome;
                txbSelecaoTelefone.Text = contatoSelecionado.telefone;

                cbxSelecaoTipo.DataSource = null;
                cbxSelecaoTipo.DataSource = listaTipos;
                cbxSelecaoTipo.SelectedIndex = contatoSelecionado.idTipo;
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (lstContatos.SelectedItem is Contato contatoSelecionado)
            {
                contatoSelecionado.nome = txbSelecaoNome.Text;
                contatoSelecionado.telefone = txbSelecaoTelefone.Text;
                contatoSelecionado.idTipo = cbxSelecaoTipo.SelectedIndex;
                
                lstContatos.DataSource = null;
                lstContatos.DataSource = listaContatos;

            }
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            if (lstContatos.SelectedItem is Contato contatoSelecionado)
            {
                listaContatos.Remove(contatoSelecionado);

                lstContatos.DataSource = null;
                lstContatos.DataSource = listaContatos;

            }
        }

        private void cbxTipo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

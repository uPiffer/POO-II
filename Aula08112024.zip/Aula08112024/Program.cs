﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Aula08112024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conexao;
            conexao = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=EO4M20242;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            conexao.Open();

            /*var insertCmd = conexao.CreateCommand();
            insertCmd.CommandText = "INSERT INTO TipoTelefone(Nome) VALUES(@nome);";
            var paramNome = new SqlParameter("nome", "Whatsapp");
            insertCmd.Parameters.Add(paramNome);
            insertCmd.ExecuteNonQuery();
            Console.WriteLine("Registro inserido");*/

            conexao.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula050824
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*
             * 1 - Pegar um numero, dizer se é par ou impar, se é positvo ou negativo 
             *

            Console.WriteLine("Digite um numero: ");
            int valor = int.Parse(Console.ReadLine()); // Usuario digita o valor
            // int valor = Convert.ToInt32(Console.ReadLine());

            if (valor % 2 == 0)
            {
                Console.WriteLine("O numero é par");
            }
            else
            {
                Console.WriteLine("O numero é impar");
            }

            if (valor > 0)
            {
                Console.WriteLine("O numero é positivo");
            }
            else if(valor < 0)
            {
                Console.WriteLine("O numero é negativo");
            }
            else
            {
                Console.WriteLine("O numero é zero");
            }

            */


            /* 
             * 2 - Dado um numero, verificar a quantidade de ocorrências de cada digito
             *
            Console.WriteLine("Digite um numero: ");
            String valor = Console.ReadLine();

            int[] contagemDigitos = new int[10];

            foreach(char c in valor)
            {
                int digito = int.Parse(c.ToString());
                contagemDigitos[digito]++;
            }

            Console.WriteLine("Contagem de ocorrencias:");

            for (int i = 0; i < contagemDigitos.Length; i++)
            {
                if (contagemDigitos[i] > 0)
                {
                    Console.WriteLine($"Digito {i}: {contagemDigitos[i]}");
                }
                
            }

            */


            /* 3 - Dado um numero entre 0 e 9, imprima DE FORMA BONITA, a tabuada de multiplicação de 0 a 10
             * 
            */

            Console.WriteLine("Digite um numero: ");
            int valor = int.Parse(Console.ReadLine());

            if(valor >= 0 && valor <= 10)
            {
                Console.WriteLine("\n\n");
                Console.WriteLine($"TABUADA DO NUMERO {valor}");
                Console.WriteLine("--------------------------");
                Console.WriteLine("\tNumero | Resultado");
                Console.WriteLine("--------------------------");

                for(int i = 0; i <= 10; i++)
                {
                    int resultado = valor * i;
                    Console.WriteLine($"\t{valor} x {i,2} = {resultado,2}");  //O ",2" é pra formatação no console, apenas pra deixar bonito
                }
                Console.WriteLine("--------------------------");
            }



        }
    }
}

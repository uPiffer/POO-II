﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240823
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Agenda telefonica.
             * Classe Contato (Nome, numero, tipo (string - final));
             * Classe ListaTelefonica(Proprietario, Lista Contatos)
             -Construtor
             -Inserir
             -Remover
             -Buscar //nome, tipo;
             -Tamanho
             -Imprimir 
            */
            ListaTelefonica l = new ListaTelefonica("Cassio");
            l.adicionar("João", "231654654", "CELULAR");
            l.adicionar("Pedro", "231654654", "WHATSAPP");
            l.imprimir();
            l.remover("Pedro");
            l.imprimir();
            l.adicionar("Joao", "123456789", Contato.tipoTelefone[0]);
            /*
            List<String> dias = new List<String>();

            dias.Add("segunda");
            dias.Add("terça");
            dias.Add("quarta");


            foreach (String s in dias){
                Console.WriteLine(s);
            }

            if (dias.Remove("xxx"))
            {
                Console.WriteLine("Removido");
            }
            else {
                Console.WriteLine("ERRO");
            }

            Console.WriteLine(dias.Count());
            dias.Contains("xxx");
            */
        }
    }
}

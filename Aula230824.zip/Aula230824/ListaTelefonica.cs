﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula230824
{
    internal class ListaTelefonica
    {
        public string proprietario { get; set; }
        private List<Contato> contatos;

        public ListaTelefonica(string proprietario)
        {
            this.proprietario = proprietario;
            contatos = new List<Contato>();
        }

        public void Inserir(string nome, string numero, string tipo)
        {
            Contato auxiliar = new Contato(nome, numero, tipo);
            contatos.Add(auxiliar); //Ou contatos.Add(new Contato(nome, numero, tipo));
        }


        public void Imprimir()
        {
            Console.WriteLine("Agenda de:" +this.proprietario);
            foreach(Contato c in contatos)
            {
                Console.WriteLine("Contato: "+c.nome+" / "+c.numero+" / "+c.tipo);
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240826_Dicionairo
{
    internal class executar
    {
        Disciplina d1 = new Disciplina("POO1", 00);
        Disciplina d2 = new Disciplina("POO2", 00);
        Disciplina d3 = new Disciplina("Eng.Soft", 00);
        Disciplina d4 = new Disciplina("ED1", 00);
        Disciplina d5 = new Disciplina("ED2", 00);

        Professor p1 = new Professor("Cassio", "111");
        Professor p2 = new Professor("Vinicius", "222");
        Professor p3 = new Professor("Saulo", "333");
        Professor p4 = new Professor("Abrantes", "444");

        
    }
}

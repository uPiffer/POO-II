﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240920RelacionamentoVertical
{
    public class Derivada : Base
    {
        public int atributo3 { get; set; }
        public int atributo4 { get; set; }
        public Derivada(int atributo3, int atributo4): base(atributo3, atributo4)
        {
            Console.WriteLine("Criação da derivada.");
            this.atributo3 = atributo3;
            this.atributo4 = atributo4;
        }

        public void Metodo1()
        {
            Console.WriteLine("Executando método 0");
        }

        public override void Metodo3()
        {
            Console.WriteLine("Executando método x");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula270924
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Contribuinte> contribuintes = new List<Contribuinte>();
            contribuintes.Add(new PFisica("123456789-00", "Gabriel", 5000));
            contribuintes.Add(new PFisica("987654321-00", "Joao", 3000));
            contribuintes.Add(new PJuridica("1347819413", "Loja A", 50000));
            contribuintes.Add(new PJuridica("1349349342", "Loja B", 30000));


            foreach(Contribuinte c in contribuintes)
            {
                if (c is PFisica pf)
                {
                    Console.WriteLine(pf.Imprimir());
                }
                else if ((c is PJuridica pj))
                {
                    Console.WriteLine(pj.Imprimir());
                }
            }
        }
    }
}

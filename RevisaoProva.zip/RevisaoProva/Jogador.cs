﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal class Jogador : Membro
    {
        public Jogador(string nome, string cPF) : base(nome, cPF)
        {
        }

        public override void Jogar()
        {
            Console.WriteLine("Joando...");
        }
    }
}

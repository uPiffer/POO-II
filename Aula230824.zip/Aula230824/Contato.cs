﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula230824
{
    internal class Contato
    {
        public string nome { get; set; }
        public string numero { get; set; }
        public string tipo { get; set; }


        public Contato(string nome, string numero, string tipo)
        {
            this.nome = nome;
            this.numero = numero;
            this.tipo = tipo;
        }

    }
}

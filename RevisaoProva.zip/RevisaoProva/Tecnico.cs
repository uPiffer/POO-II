﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal class Tecnico : Membro, iGerencia
    {
        public Tecnico(string nome, string cPF) : base(nome, cPF)
        {
        }

        public override void Jogar()
        {
            Console.WriteLine("Aposentado");
        }

        public void OrganizarTime()
        {
            Console.WriteLine("Organizando Time");
        }

        public void Treinar()
        {
            Console.WriteLine("Treinando Time");
        }

  
    }
}

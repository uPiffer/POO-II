﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240826_Dicionairo
{
    internal class Disciplina
    {
        public string nome { get; set; }
        public int ch {  get; set; }
        public List<Professor> profs { get; set; }

        public Disciplina(string nome, int ch)
        {
            this.nome = nome;
            this.ch = ch;
            profs = new List<Professor>();
        }
        public void adicionarProfessor(Professor professor)
        {
            profs.Add(professor);
            professor.adicionarDisciplina(this);
        }
    } 
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240418
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                double saldo = 1000;
                bool tiomorto = true;
                int filhos=2;
                double valorpartilha = 0;

                if (tiomorto) {
                    valorpartilha = saldo / filhos;
                }

                Console.WriteLine("VALOR: "+valorpartilha);

            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("SEM FILHOS - PERDEU DINHEIRO...");
                Console.WriteLine(ex.Message);

            }
            finally
            {
                Console.WriteLine("Finalizando...");
            }
        }
    }
}
